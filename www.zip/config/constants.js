angular.module('pocket.constants', [])

.constant("PocketPointingConstants", {
  "HOST": "@@apiUrl",
  "PORT": "",
  "LOCAL_STORAGE": "APP_POCKET_LOGGED"
})

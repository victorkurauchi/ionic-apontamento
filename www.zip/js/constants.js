angular.module('pocket.constants', [])

.constant("PocketPointingConstants", {
  "HOST": "http://pocket-pointing.meteor.com",
  "PORT": "",
  "LOCAL_STORAGE": "APP_POCKET_LOGGED"
})
